
package Classes;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javazoom.jl.decoder.JavaLayerException;
import javazoom.jl.player.*;

public class LoginForm extends javax.swing.JFrame
{
     Connect connect = new Connect();

     public LoginForm()
    {
       
        initComponents();
        connect.Connect();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Background_jPanel = new javax.swing.JPanel();
        username_jLabel = new javax.swing.JLabel();
        password_jLabel = new javax.swing.JLabel();
        username_jTextField = new javax.swing.JTextField();
        password_jPasswordField = new javax.swing.JPasswordField();
        LOGIN_jButton = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(700, 450));
        setResizable(false);
        setSize(new java.awt.Dimension(700, 450));
        getContentPane().setLayout(null);

        Background_jPanel.setMaximumSize(new java.awt.Dimension(700, 450));
        Background_jPanel.setMinimumSize(new java.awt.Dimension(700, 450));
        Background_jPanel.setLayout(null);

        username_jLabel.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        username_jLabel.setText("USER NAME");
        username_jLabel.setMaximumSize(new java.awt.Dimension(85, 20));
        username_jLabel.setMinimumSize(new java.awt.Dimension(85, 20));
        username_jLabel.setPreferredSize(new java.awt.Dimension(85, 20));
        Background_jPanel.add(username_jLabel);
        username_jLabel.setBounds(400, 200, 90, 30);

        password_jLabel.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        password_jLabel.setText("PASSWORD");
        password_jLabel.setMaximumSize(new java.awt.Dimension(85, 20));
        password_jLabel.setMinimumSize(new java.awt.Dimension(85, 20));
        password_jLabel.setPreferredSize(new java.awt.Dimension(85, 20));
        Background_jPanel.add(password_jLabel);
        password_jLabel.setBounds(400, 260, 100, 30);

        username_jTextField.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        Background_jPanel.add(username_jTextField);
        username_jTextField.setBounds(510, 200, 150, 30);
        Background_jPanel.add(password_jPasswordField);
        password_jPasswordField.setBounds(510, 260, 150, 30);

        LOGIN_jButton.setBackground(new java.awt.Color(102, 102, 102));
        LOGIN_jButton.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        LOGIN_jButton.setText("LOGIN");
        LOGIN_jButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        LOGIN_jButton.setOpaque(false);
        LOGIN_jButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LOGIN_jButtonActionPerformed(evt);
            }
        });
        Background_jPanel.add(LOGIN_jButton);
        LOGIN_jButton.setBounds(530, 330, 90, 25);

        jLabel1.setBackground(new java.awt.Color(0, 0, 0));
        jLabel1.setFont(new java.awt.Font("Buxton Sketch", 1, 36)); // NOI18N
        jLabel1.setText("STUDENT MANAGEMENT SYSTEM");
        Background_jPanel.add(jLabel1);
        jLabel1.setBounds(60, 20, 600, 60);

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/project3.jpg"))); // NOI18N
        jLabel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        Background_jPanel.add(jLabel3);
        jLabel3.setBounds(-20, -20, 890, 480);

        getContentPane().add(Background_jPanel);
        Background_jPanel.setBounds(0, 0, 700, 450);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void LOGIN_jButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LOGIN_jButtonActionPerformed
        
        
/*        String pass = String.valueOf(password_jPasswordField.getPassword());
        String user=username_jTextField.getText();
        String user1 = null ,pass1 = null;

        try
        {
            connect.st = connect.conn.createStatement();
            connect.rs=connect.st.executeQuery("select username,password from password where username="+" '"+ user+ "'"+ " and password = "+"'" + pass + "'" ); 
            if(connect.rs.next())
            {
                user1=connect.rs.getString("USERNAME");
                pass1=connect.rs.getString("PASSWORD");
            }
            
            connect.rs.close();
            connect.st.close();
               
            if(user1!= null && pass1!= null)
            {
                System.out.println("USER AND PASSWORD is correct ");
                
                
            
                          JOptionPane.showMessageDialog(null, "ACCESS GRANTED!!");
             */   HOME h = new HOME();
                h.setVisible(true);
                dispose();
             
           /* }
            else if (user1.isEmpty()== true && pass1.isEmpty()== true)
            {
                System.out.println("user or pass is not correct ");
                JOptionPane.showMessageDialog(null, "Failed!!");
            }
            
        }
       catch(SQLException e)
        {
           JOptionPane.showConfirmDialog(null, e); 
        } 
       */
        
    }//GEN-LAST:event_LOGIN_jButtonActionPerformed
    
    public static void main(String args[]) 
    {
        java.awt.EventQueue.invokeLater(new Runnable()
        {
            public void run()
            {
                new LoginForm().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Background_jPanel;
    private javax.swing.JButton LOGIN_jButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel password_jLabel;
    private javax.swing.JPasswordField password_jPasswordField;
    private javax.swing.JLabel username_jLabel;
    private javax.swing.JTextField username_jTextField;
    // End of variables declaration//GEN-END:variables
}
