package Classes;
import com.sun.glass.events.KeyEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.ButtonGroup;
import javax.swing.JOptionPane;
public class Result_Form extends javax.swing.JFrame
{
    Connect connect = new Connect();
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jSplitPane1 = new javax.swing.JSplitPane();
        StudentInformation_jLabel = new javax.swing.JLabel();
        search_jTextField = new javax.swing.JTextField();
        CourseFee_jLabel6 = new javax.swing.JLabel();
        CourseFee_jLabel10 = new javax.swing.JLabel();
        CourseFee_jLabel11 = new javax.swing.JLabel();
        CourseFee_jLabel13 = new javax.swing.JLabel();
        CourseFee_jLabel14 = new javax.swing.JLabel();
        Home_jButton = new javax.swing.JButton();
        clear_jButton = new javax.swing.JButton();
        Update_jButton = new javax.swing.JButton();
        Delete_jButton = new javax.swing.JButton();
        Add_jButton = new javax.swing.JButton();
        jTextField8 = new javax.swing.JTextField();
        jComboBox4 = new javax.swing.JComboBox<>();
        jComboBox1 = new javax.swing.JComboBox<>();
        jComboBox2 = new javax.swing.JComboBox<>();
        jComboBox3 = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        CourseFee_jLabel7 = new javax.swing.JLabel();
        mainback_jLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("STUDENT INFORMATION");
        setMinimumSize(new java.awt.Dimension(914, 552));
        setResizable(false);
        setSize(new java.awt.Dimension(914, 552));
        getContentPane().setLayout(null);

        StudentInformation_jLabel.setFont(new java.awt.Font("Buxton Sketch", 1, 36)); // NOI18N
        StudentInformation_jLabel.setForeground(new java.awt.Color(102, 102, 102));
        StudentInformation_jLabel.setText("OVERALL RESULT");
        getContentPane().add(StudentInformation_jLabel);
        StudentInformation_jLabel.setBounds(30, 0, 255, 45);

        search_jTextField.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        search_jTextField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        search_jTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                search_jTextFieldActionPerformed(evt);
            }
        });
        search_jTextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                search_jTextFieldKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                search_jTextFieldKeyReleased(evt);
            }
        });
        getContentPane().add(search_jTextField);
        search_jTextField.setBounds(720, 20, 117, 19);

        CourseFee_jLabel6.setBackground(new java.awt.Color(0, 0, 0));
        CourseFee_jLabel6.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        CourseFee_jLabel6.setForeground(new java.awt.Color(102, 102, 102));
        CourseFee_jLabel6.setText("Search");
        CourseFee_jLabel6.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        CourseFee_jLabel6.setPreferredSize(new java.awt.Dimension(145, 20));
        getContentPane().add(CourseFee_jLabel6);
        CourseFee_jLabel6.setBounds(640, 20, 130, 20);

        CourseFee_jLabel10.setBackground(new java.awt.Color(0, 0, 0));
        CourseFee_jLabel10.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        CourseFee_jLabel10.setForeground(new java.awt.Color(102, 102, 102));
        CourseFee_jLabel10.setText("Department");
        CourseFee_jLabel10.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        CourseFee_jLabel10.setPreferredSize(new java.awt.Dimension(145, 20));
        getContentPane().add(CourseFee_jLabel10);
        CourseFee_jLabel10.setBounds(40, 90, 130, 20);

        CourseFee_jLabel11.setBackground(new java.awt.Color(0, 0, 0));
        CourseFee_jLabel11.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        CourseFee_jLabel11.setForeground(new java.awt.Color(102, 102, 102));
        CourseFee_jLabel11.setText("Program ID");
        CourseFee_jLabel11.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        CourseFee_jLabel11.setPreferredSize(new java.awt.Dimension(145, 20));
        getContentPane().add(CourseFee_jLabel11);
        CourseFee_jLabel11.setBounds(40, 120, 130, 30);

        CourseFee_jLabel13.setBackground(new java.awt.Color(0, 0, 0));
        CourseFee_jLabel13.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        CourseFee_jLabel13.setForeground(new java.awt.Color(102, 102, 102));
        CourseFee_jLabel13.setText("Session");
        CourseFee_jLabel13.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        CourseFee_jLabel13.setPreferredSize(new java.awt.Dimension(145, 20));
        getContentPane().add(CourseFee_jLabel13);
        CourseFee_jLabel13.setBounds(40, 160, 130, 20);

        CourseFee_jLabel14.setBackground(new java.awt.Color(0, 0, 0));
        CourseFee_jLabel14.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        CourseFee_jLabel14.setForeground(new java.awt.Color(102, 102, 102));
        CourseFee_jLabel14.setText("Year");
        CourseFee_jLabel14.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        CourseFee_jLabel14.setPreferredSize(new java.awt.Dimension(145, 20));
        getContentPane().add(CourseFee_jLabel14);
        CourseFee_jLabel14.setBounds(40, 200, 130, 20);

        Home_jButton.setBackground(new java.awt.Color(102, 102, 102));
        Home_jButton.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        Home_jButton.setForeground(new java.awt.Color(255, 255, 255));
        Home_jButton.setText("HOME");
        Home_jButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        Home_jButton.setMaximumSize(new java.awt.Dimension(100, 25));
        Home_jButton.setMinimumSize(new java.awt.Dimension(100, 25));
        Home_jButton.setOpaque(false);
        Home_jButton.setPreferredSize(new java.awt.Dimension(100, 25));
        Home_jButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Home_jButtonActionPerformed(evt);
            }
        });
        getContentPane().add(Home_jButton);
        Home_jButton.setBounds(640, 160, 100, 25);

        clear_jButton.setBackground(new java.awt.Color(102, 102, 102));
        clear_jButton.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        clear_jButton.setForeground(new java.awt.Color(255, 255, 255));
        clear_jButton.setText("CLEAR");
        clear_jButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        clear_jButton.setMaximumSize(new java.awt.Dimension(100, 25));
        clear_jButton.setMinimumSize(new java.awt.Dimension(100, 25));
        clear_jButton.setOpaque(false);
        clear_jButton.setPreferredSize(new java.awt.Dimension(100, 25));
        clear_jButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clear_jButtonActionPerformed(evt);
            }
        });
        getContentPane().add(clear_jButton);
        clear_jButton.setBounds(640, 130, 100, 25);

        Update_jButton.setBackground(new java.awt.Color(102, 102, 102));
        Update_jButton.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        Update_jButton.setForeground(new java.awt.Color(255, 255, 255));
        Update_jButton.setText("UPDATE");
        Update_jButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        Update_jButton.setMaximumSize(new java.awt.Dimension(100, 25));
        Update_jButton.setMinimumSize(new java.awt.Dimension(100, 25));
        Update_jButton.setOpaque(false);
        Update_jButton.setPreferredSize(new java.awt.Dimension(100, 25));
        Update_jButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Update_jButtonActionPerformed(evt);
            }
        });
        getContentPane().add(Update_jButton);
        Update_jButton.setBounds(640, 100, 100, 25);

        Delete_jButton.setBackground(new java.awt.Color(102, 102, 102));
        Delete_jButton.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        Delete_jButton.setForeground(new java.awt.Color(255, 255, 255));
        Delete_jButton.setText("DELETE");
        Delete_jButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        Delete_jButton.setMaximumSize(new java.awt.Dimension(100, 25));
        Delete_jButton.setMinimumSize(new java.awt.Dimension(100, 25));
        Delete_jButton.setOpaque(false);
        Delete_jButton.setPreferredSize(new java.awt.Dimension(100, 25));
        Delete_jButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Delete_jButtonActionPerformed(evt);
            }
        });
        getContentPane().add(Delete_jButton);
        Delete_jButton.setBounds(640, 190, 100, 25);

        Add_jButton.setBackground(new java.awt.Color(102, 102, 102));
        Add_jButton.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        Add_jButton.setForeground(new java.awt.Color(255, 255, 255));
        Add_jButton.setText("ADD");
        Add_jButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        Add_jButton.setMaximumSize(new java.awt.Dimension(100, 25));
        Add_jButton.setMinimumSize(new java.awt.Dimension(100, 25));
        Add_jButton.setOpaque(false);
        Add_jButton.setPreferredSize(new java.awt.Dimension(100, 25));
        Add_jButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Add_jButtonActionPerformed(evt);
            }
        });
        getContentPane().add(Add_jButton);
        Add_jButton.setBounds(640, 60, 100, 25);
        getContentPane().add(jTextField8);
        jTextField8.setBounds(160, 130, 210, 20);

        jComboBox4.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Karachi", "Islamabad" }));
        jComboBox4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox4ActionPerformed(evt);
            }
        });
        getContentPane().add(jComboBox4);
        jComboBox4.setBounds(160, 50, 210, 20);

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Fall", "Spring" }));
        getContentPane().add(jComboBox1);
        jComboBox1.setBounds(160, 160, 210, 20);

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "2015", "2016", "2017", "2018" }));
        getContentPane().add(jComboBox2);
        jComboBox2.setBounds(160, 200, 210, 20);

        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Management Science", "Computer Science" }));
        getContentPane().add(jComboBox3);
        jComboBox3.setBounds(160, 90, 210, 20);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Student ID", "Student Name", "GPA", "CGPA", "Status"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(120, 280, 660, 120);

        CourseFee_jLabel7.setBackground(new java.awt.Color(0, 0, 0));
        CourseFee_jLabel7.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        CourseFee_jLabel7.setForeground(new java.awt.Color(102, 102, 102));
        CourseFee_jLabel7.setText("Campus");
        CourseFee_jLabel7.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        CourseFee_jLabel7.setPreferredSize(new java.awt.Dimension(145, 20));
        getContentPane().add(CourseFee_jLabel7);
        CourseFee_jLabel7.setBounds(40, 50, 130, 20);

        mainback_jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Student-ResourcesSmall.jpg"))); // NOI18N
        getContentPane().add(mainback_jLabel);
        mainback_jLabel.setBounds(0, -170, 910, 730);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void Home_jButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Home_jButtonActionPerformed
        HOME h = new HOME();
        h.setVisible(true);
        dispose();
    }//GEN-LAST:event_Home_jButtonActionPerformed

    private void Add_jButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Add_jButtonActionPerformed
        
       
    }//GEN-LAST:event_Add_jButtonActionPerformed

    private void Delete_jButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Delete_jButtonActionPerformed
        
        
    }//GEN-LAST:event_Delete_jButtonActionPerformed

    private void search_jTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_search_jTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_search_jTextFieldActionPerformed

    private void search_jTextFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_search_jTextFieldKeyReleased
       
       
    }//GEN-LAST:event_search_jTextFieldKeyReleased

    private void clear_jButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clear_jButtonActionPerformed
        
      
        
    }//GEN-LAST:event_clear_jButtonActionPerformed

    private void Update_jButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Update_jButtonActionPerformed
       
            
    }//GEN-LAST:event_Update_jButtonActionPerformed

    private void search_jTextFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_search_jTextFieldKeyPressed
        
    }//GEN-LAST:event_search_jTextFieldKeyPressed

    private void jComboBox4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox4ActionPerformed

    public static void main(String args[]) 
    {
        java.awt.EventQueue.invokeLater(new Runnable()
        {
            public void run() 
            {
                new Result_Form().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Add_jButton;
    private javax.swing.JLabel CourseFee_jLabel10;
    private javax.swing.JLabel CourseFee_jLabel11;
    private javax.swing.JLabel CourseFee_jLabel13;
    private javax.swing.JLabel CourseFee_jLabel14;
    private javax.swing.JLabel CourseFee_jLabel6;
    private javax.swing.JLabel CourseFee_jLabel7;
    private javax.swing.JButton Delete_jButton;
    private javax.swing.JButton Home_jButton;
    private javax.swing.JLabel StudentInformation_jLabel;
    private javax.swing.JButton Update_jButton;
    private javax.swing.JButton clear_jButton;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JComboBox<String> jComboBox3;
    private javax.swing.JComboBox<String> jComboBox4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSplitPane jSplitPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JLabel mainback_jLabel;
    private javax.swing.JTextField search_jTextField;
    // End of variables declaration//GEN-END:variables
}
