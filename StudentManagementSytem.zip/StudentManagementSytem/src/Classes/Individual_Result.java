package Classes;
import com.sun.glass.events.KeyEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.ButtonGroup;
import javax.swing.JOptionPane;
public class Individual_Result extends javax.swing.JFrame
{
    Connect connect = new Connect();
   
    
    
     
    public Individual_Result() 
    {
        initComponents();
        connect.Connect();
        
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jSplitPane1 = new javax.swing.JSplitPane();
        StudentInformation_jLabel = new javax.swing.JLabel();
        Home_jButton = new javax.swing.JButton();
        search_jTextField = new javax.swing.JTextField();
        clear_jButton = new javax.swing.JButton();
        CourseFee_jLabel11 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jTextField9 = new javax.swing.JTextField();
        CourseFee_jLabel12 = new javax.swing.JLabel();
        jComboBox5 = new javax.swing.JComboBox<>();
        jComboBox6 = new javax.swing.JComboBox<>();
        CourseFee_jLabel15 = new javax.swing.JLabel();
        mainback_jLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("STUDENT INFORMATION");
        setMinimumSize(new java.awt.Dimension(914, 552));
        setResizable(false);
        setSize(new java.awt.Dimension(914, 552));
        getContentPane().setLayout(null);

        StudentInformation_jLabel.setFont(new java.awt.Font("Buxton Sketch", 1, 36)); // NOI18N
        StudentInformation_jLabel.setForeground(new java.awt.Color(102, 102, 102));
        StudentInformation_jLabel.setText("STUDENT RESULT");
        getContentPane().add(StudentInformation_jLabel);
        StudentInformation_jLabel.setBounds(320, 0, 273, 45);

        Home_jButton.setBackground(new java.awt.Color(102, 102, 102));
        Home_jButton.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        Home_jButton.setForeground(new java.awt.Color(255, 255, 255));
        Home_jButton.setText("HOME");
        Home_jButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        Home_jButton.setMaximumSize(new java.awt.Dimension(100, 25));
        Home_jButton.setMinimumSize(new java.awt.Dimension(100, 25));
        Home_jButton.setOpaque(false);
        Home_jButton.setPreferredSize(new java.awt.Dimension(100, 25));
        Home_jButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Home_jButtonActionPerformed(evt);
            }
        });
        getContentPane().add(Home_jButton);
        Home_jButton.setBounds(520, 110, 100, 25);

        search_jTextField.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        search_jTextField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        search_jTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                search_jTextFieldActionPerformed(evt);
            }
        });
        search_jTextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                search_jTextFieldKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                search_jTextFieldKeyReleased(evt);
            }
        });
        getContentPane().add(search_jTextField);
        search_jTextField.setBounds(780, 20, 117, 19);

        clear_jButton.setBackground(new java.awt.Color(102, 102, 102));
        clear_jButton.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        clear_jButton.setForeground(new java.awt.Color(255, 255, 255));
        clear_jButton.setText("CLEAR");
        clear_jButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        clear_jButton.setMaximumSize(new java.awt.Dimension(100, 25));
        clear_jButton.setMinimumSize(new java.awt.Dimension(100, 25));
        clear_jButton.setOpaque(false);
        clear_jButton.setPreferredSize(new java.awt.Dimension(100, 25));
        clear_jButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clear_jButtonActionPerformed(evt);
            }
        });
        getContentPane().add(clear_jButton);
        clear_jButton.setBounds(410, 110, 100, 25);

        CourseFee_jLabel11.setBackground(new java.awt.Color(0, 0, 0));
        CourseFee_jLabel11.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        CourseFee_jLabel11.setForeground(new java.awt.Color(102, 102, 102));
        CourseFee_jLabel11.setText("Year");
        CourseFee_jLabel11.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        CourseFee_jLabel11.setPreferredSize(new java.awt.Dimension(145, 20));
        getContentPane().add(CourseFee_jLabel11);
        CourseFee_jLabel11.setBounds(420, 60, 130, 30);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Course", "Max Marks", "Obtained Marks", "GPA", "CGPA", "Status"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(30, 170, 860, 110);
        getContentPane().add(jTextField9);
        jTextField9.setBounds(140, 70, 210, 20);

        CourseFee_jLabel12.setBackground(new java.awt.Color(0, 0, 0));
        CourseFee_jLabel12.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        CourseFee_jLabel12.setForeground(new java.awt.Color(102, 102, 102));
        CourseFee_jLabel12.setText("Student ID");
        CourseFee_jLabel12.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        CourseFee_jLabel12.setPreferredSize(new java.awt.Dimension(145, 20));
        getContentPane().add(CourseFee_jLabel12);
        CourseFee_jLabel12.setBounds(40, 70, 130, 30);

        jComboBox5.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "2015", "2016", "2017", "2018", " " }));
        getContentPane().add(jComboBox5);
        jComboBox5.setBounds(470, 70, 210, 20);

        jComboBox6.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Fall", "Spring" }));
        getContentPane().add(jComboBox6);
        jComboBox6.setBounds(140, 110, 210, 20);

        CourseFee_jLabel15.setBackground(new java.awt.Color(0, 0, 0));
        CourseFee_jLabel15.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        CourseFee_jLabel15.setForeground(new java.awt.Color(102, 102, 102));
        CourseFee_jLabel15.setText("Session");
        CourseFee_jLabel15.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        CourseFee_jLabel15.setPreferredSize(new java.awt.Dimension(145, 20));
        getContentPane().add(CourseFee_jLabel15);
        CourseFee_jLabel15.setBounds(40, 110, 130, 30);

        mainback_jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/p02vdpfn.jpg"))); // NOI18N
        getContentPane().add(mainback_jLabel);
        mainback_jLabel.setBounds(0, 0, 910, 560);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void Home_jButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Home_jButtonActionPerformed
        HOME h = new HOME();
        h.setVisible(true);
        dispose();
    }//GEN-LAST:event_Home_jButtonActionPerformed

    private void search_jTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_search_jTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_search_jTextFieldActionPerformed

    private void search_jTextFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_search_jTextFieldKeyReleased
     
    }//GEN-LAST:event_search_jTextFieldKeyReleased

    private void clear_jButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clear_jButtonActionPerformed
        
        
    }//GEN-LAST:event_clear_jButtonActionPerformed

    private void search_jTextFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_search_jTextFieldKeyPressed
        
         
    }//GEN-LAST:event_search_jTextFieldKeyPressed

    public static void main(String args[]) 
    {
        java.awt.EventQueue.invokeLater(new Runnable()
        {
            public void run() 
            {
                new Individual_Result().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel CourseFee_jLabel11;
    private javax.swing.JLabel CourseFee_jLabel12;
    private javax.swing.JLabel CourseFee_jLabel15;
    private javax.swing.JButton Home_jButton;
    private javax.swing.JLabel StudentInformation_jLabel;
    private javax.swing.JButton clear_jButton;
    private javax.swing.JComboBox<String> jComboBox5;
    private javax.swing.JComboBox<String> jComboBox6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSplitPane jSplitPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField9;
    private javax.swing.JLabel mainback_jLabel;
    private javax.swing.JTextField search_jTextField;
    // End of variables declaration//GEN-END:variables
}
