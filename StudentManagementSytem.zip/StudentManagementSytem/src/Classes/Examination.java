package Classes;
import com.sun.glass.events.KeyEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.ButtonGroup;
import javax.swing.JOptionPane;
public class Examination extends javax.swing.JFrame
{
    Connect connect = new Connect();
   
     
    public Examination() 
    {
        initComponents();
        connect.Connect();
        
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jSplitPane1 = new javax.swing.JSplitPane();
        StudentInformation_jLabel = new javax.swing.JLabel();
        search_jTextField = new javax.swing.JTextField();
        CourseFee_jLabel1 = new javax.swing.JLabel();
        CourseFee_jLabel2 = new javax.swing.JLabel();
        CourseFee_jLabel3 = new javax.swing.JLabel();
        CourseFee_jLabel5 = new javax.swing.JLabel();
        CourseFee_jLabel7 = new javax.swing.JLabel();
        CourseFee_jLabel8 = new javax.swing.JLabel();
        Home_jButton = new javax.swing.JButton();
        clear_jButton = new javax.swing.JButton();
        Update_jButton = new javax.swing.JButton();
        Delete_jButton = new javax.swing.JButton();
        Add_jButton = new javax.swing.JButton();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jTextField5 = new javax.swing.JTextField();
        jTextField6 = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jComboBox1 = new javax.swing.JComboBox<>();
        CourseFee_jLabel9 = new javax.swing.JLabel();
        mainback_jLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("STUDENT INFORMATION");
        setMinimumSize(new java.awt.Dimension(914, 552));
        setResizable(false);
        setSize(new java.awt.Dimension(914, 552));
        getContentPane().setLayout(null);

        StudentInformation_jLabel.setFont(new java.awt.Font("Buxton Sketch", 1, 36)); // NOI18N
        StudentInformation_jLabel.setForeground(new java.awt.Color(102, 102, 102));
        StudentInformation_jLabel.setText("EXAMINATION");
        getContentPane().add(StudentInformation_jLabel);
        StudentInformation_jLabel.setBounds(250, 0, 210, 45);

        search_jTextField.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        search_jTextField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        search_jTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                search_jTextFieldActionPerformed(evt);
            }
        });
        search_jTextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                search_jTextFieldKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                search_jTextFieldKeyReleased(evt);
            }
        });
        getContentPane().add(search_jTextField);
        search_jTextField.setBounds(680, 20, 117, 19);

        CourseFee_jLabel1.setBackground(new java.awt.Color(0, 0, 0));
        CourseFee_jLabel1.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        CourseFee_jLabel1.setForeground(new java.awt.Color(102, 102, 102));
        CourseFee_jLabel1.setText("Obtained Marks");
        CourseFee_jLabel1.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        CourseFee_jLabel1.setPreferredSize(new java.awt.Dimension(145, 20));
        getContentPane().add(CourseFee_jLabel1);
        CourseFee_jLabel1.setBounds(40, 210, 130, 20);

        CourseFee_jLabel2.setBackground(new java.awt.Color(0, 0, 0));
        CourseFee_jLabel2.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        CourseFee_jLabel2.setForeground(new java.awt.Color(102, 102, 102));
        CourseFee_jLabel2.setText("SEARCH");
        CourseFee_jLabel2.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        CourseFee_jLabel2.setPreferredSize(new java.awt.Dimension(145, 20));
        getContentPane().add(CourseFee_jLabel2);
        CourseFee_jLabel2.setBounds(600, 20, 66, 20);

        CourseFee_jLabel3.setBackground(new java.awt.Color(0, 0, 0));
        CourseFee_jLabel3.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        CourseFee_jLabel3.setForeground(new java.awt.Color(102, 102, 102));
        CourseFee_jLabel3.setText("Student ID");
        CourseFee_jLabel3.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        CourseFee_jLabel3.setPreferredSize(new java.awt.Dimension(145, 20));
        getContentPane().add(CourseFee_jLabel3);
        CourseFee_jLabel3.setBounds(40, 90, 100, 20);

        CourseFee_jLabel5.setBackground(new java.awt.Color(0, 0, 0));
        CourseFee_jLabel5.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        CourseFee_jLabel5.setForeground(new java.awt.Color(102, 102, 102));
        CourseFee_jLabel5.setText("Course Code");
        CourseFee_jLabel5.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        CourseFee_jLabel5.setPreferredSize(new java.awt.Dimension(145, 20));
        getContentPane().add(CourseFee_jLabel5);
        CourseFee_jLabel5.setBounds(40, 130, 130, 20);

        CourseFee_jLabel7.setBackground(new java.awt.Color(0, 0, 0));
        CourseFee_jLabel7.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        CourseFee_jLabel7.setForeground(new java.awt.Color(102, 102, 102));
        CourseFee_jLabel7.setText("Max Marks");
        CourseFee_jLabel7.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        CourseFee_jLabel7.setPreferredSize(new java.awt.Dimension(145, 20));
        getContentPane().add(CourseFee_jLabel7);
        CourseFee_jLabel7.setBounds(40, 170, 130, 20);

        CourseFee_jLabel8.setBackground(new java.awt.Color(0, 0, 0));
        CourseFee_jLabel8.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        CourseFee_jLabel8.setForeground(new java.awt.Color(102, 102, 102));
        CourseFee_jLabel8.setText("Status");
        CourseFee_jLabel8.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        CourseFee_jLabel8.setPreferredSize(new java.awt.Dimension(145, 20));
        getContentPane().add(CourseFee_jLabel8);
        CourseFee_jLabel8.setBounds(40, 290, 130, 20);

        Home_jButton.setBackground(new java.awt.Color(102, 102, 102));
        Home_jButton.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        Home_jButton.setForeground(new java.awt.Color(51, 51, 51));
        Home_jButton.setText("HOME");
        Home_jButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        Home_jButton.setMaximumSize(new java.awt.Dimension(100, 25));
        Home_jButton.setMinimumSize(new java.awt.Dimension(100, 25));
        Home_jButton.setOpaque(false);
        Home_jButton.setPreferredSize(new java.awt.Dimension(100, 25));
        Home_jButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Home_jButtonActionPerformed(evt);
            }
        });
        getContentPane().add(Home_jButton);
        Home_jButton.setBounds(560, 390, 100, 25);

        clear_jButton.setBackground(new java.awt.Color(102, 102, 102));
        clear_jButton.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        clear_jButton.setForeground(new java.awt.Color(51, 51, 51));
        clear_jButton.setText("CLEAR");
        clear_jButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        clear_jButton.setMaximumSize(new java.awt.Dimension(100, 25));
        clear_jButton.setMinimumSize(new java.awt.Dimension(100, 25));
        clear_jButton.setOpaque(false);
        clear_jButton.setPreferredSize(new java.awt.Dimension(100, 25));
        clear_jButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clear_jButtonActionPerformed(evt);
            }
        });
        getContentPane().add(clear_jButton);
        clear_jButton.setBounds(430, 390, 100, 25);

        Update_jButton.setBackground(new java.awt.Color(102, 102, 102));
        Update_jButton.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        Update_jButton.setForeground(new java.awt.Color(51, 51, 51));
        Update_jButton.setText("UPDATE");
        Update_jButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        Update_jButton.setMaximumSize(new java.awt.Dimension(100, 25));
        Update_jButton.setMinimumSize(new java.awt.Dimension(100, 25));
        Update_jButton.setOpaque(false);
        Update_jButton.setPreferredSize(new java.awt.Dimension(100, 25));
        Update_jButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Update_jButtonActionPerformed(evt);
            }
        });
        getContentPane().add(Update_jButton);
        Update_jButton.setBounds(300, 390, 100, 25);

        Delete_jButton.setBackground(new java.awt.Color(102, 102, 102));
        Delete_jButton.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        Delete_jButton.setForeground(new java.awt.Color(51, 51, 51));
        Delete_jButton.setText("DELETE");
        Delete_jButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        Delete_jButton.setMaximumSize(new java.awt.Dimension(100, 25));
        Delete_jButton.setMinimumSize(new java.awt.Dimension(100, 25));
        Delete_jButton.setOpaque(false);
        Delete_jButton.setPreferredSize(new java.awt.Dimension(100, 25));
        Delete_jButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Delete_jButtonActionPerformed(evt);
            }
        });
        getContentPane().add(Delete_jButton);
        Delete_jButton.setBounds(180, 390, 100, 25);

        Add_jButton.setBackground(new java.awt.Color(102, 102, 102));
        Add_jButton.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        Add_jButton.setForeground(new java.awt.Color(51, 51, 51));
        Add_jButton.setText("ADD");
        Add_jButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        Add_jButton.setMaximumSize(new java.awt.Dimension(100, 25));
        Add_jButton.setMinimumSize(new java.awt.Dimension(100, 25));
        Add_jButton.setOpaque(false);
        Add_jButton.setPreferredSize(new java.awt.Dimension(100, 25));
        Add_jButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Add_jButtonActionPerformed(evt);
            }
        });
        getContentPane().add(Add_jButton);
        Add_jButton.setBounds(50, 390, 100, 25);
        getContentPane().add(jTextField2);
        jTextField2.setBounds(160, 90, 210, 20);
        getContentPane().add(jTextField3);
        jTextField3.setBounds(160, 130, 210, 20);
        getContentPane().add(jTextField4);
        jTextField4.setBounds(160, 170, 210, 20);

        jTextField5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField5ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField5);
        jTextField5.setBounds(160, 210, 210, 20);

        jTextField6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField6ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField6);
        jTextField6.setBounds(160, 250, 210, 20);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Course Code", "Student ID", "Max Marks", "Obtained Marks", "Grade", "Status"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(390, 90, 520, 220);

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pass", "Fail" }));
        getContentPane().add(jComboBox1);
        jComboBox1.setBounds(160, 290, 210, 20);

        CourseFee_jLabel9.setBackground(new java.awt.Color(0, 0, 0));
        CourseFee_jLabel9.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        CourseFee_jLabel9.setForeground(new java.awt.Color(102, 102, 102));
        CourseFee_jLabel9.setText("Grade");
        CourseFee_jLabel9.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        CourseFee_jLabel9.setPreferredSize(new java.awt.Dimension(145, 20));
        getContentPane().add(CourseFee_jLabel9);
        CourseFee_jLabel9.setBounds(40, 250, 130, 20);

        mainback_jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/p02vdpfn.jpg"))); // NOI18N
        getContentPane().add(mainback_jLabel);
        mainback_jLabel.setBounds(0, 0, 910, 560);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void Home_jButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Home_jButtonActionPerformed
        HOME h = new HOME();
        h.setVisible(true);
        dispose();
    }//GEN-LAST:event_Home_jButtonActionPerformed

    private void Add_jButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Add_jButtonActionPerformed
        
        
    }//GEN-LAST:event_Add_jButtonActionPerformed

    private void Delete_jButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Delete_jButtonActionPerformed
        
       
    }//GEN-LAST:event_Delete_jButtonActionPerformed

    private void search_jTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_search_jTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_search_jTextFieldActionPerformed

    private void search_jTextFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_search_jTextFieldKeyReleased
       
       
    }//GEN-LAST:event_search_jTextFieldKeyReleased

    private void clear_jButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clear_jButtonActionPerformed
        
        
        
    }//GEN-LAST:event_clear_jButtonActionPerformed

    private void Update_jButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Update_jButtonActionPerformed
       
    }//GEN-LAST:event_Update_jButtonActionPerformed

    private void search_jTextFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_search_jTextFieldKeyPressed
       
    }//GEN-LAST:event_search_jTextFieldKeyPressed

    private void jTextField5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField5ActionPerformed

    private void jTextField6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField6ActionPerformed

    public static void main(String args[]) 
    {
        java.awt.EventQueue.invokeLater(new Runnable()
        {
            public void run() 
            {
                new Examination().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Add_jButton;
    private javax.swing.JLabel CourseFee_jLabel1;
    private javax.swing.JLabel CourseFee_jLabel2;
    private javax.swing.JLabel CourseFee_jLabel3;
    private javax.swing.JLabel CourseFee_jLabel5;
    private javax.swing.JLabel CourseFee_jLabel7;
    private javax.swing.JLabel CourseFee_jLabel8;
    private javax.swing.JLabel CourseFee_jLabel9;
    private javax.swing.JButton Delete_jButton;
    private javax.swing.JButton Home_jButton;
    private javax.swing.JLabel StudentInformation_jLabel;
    private javax.swing.JButton Update_jButton;
    private javax.swing.JButton clear_jButton;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSplitPane jSplitPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JLabel mainback_jLabel;
    private javax.swing.JTextField search_jTextField;
    // End of variables declaration//GEN-END:variables
}
