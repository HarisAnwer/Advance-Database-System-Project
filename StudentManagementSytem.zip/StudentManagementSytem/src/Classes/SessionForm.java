
package Classes;
import com.sun.glass.events.KeyEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class SessionForm extends javax.swing.JFrame
{
    Connect connect = new Connect();
    
    public SessionForm()
    {
        initComponents();
        connect.Connect();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        CourseInformation_jLabel = new javax.swing.JLabel();
        Home_jButton = new javax.swing.JButton();
        Course_jPanel = new javax.swing.JPanel();
        CourseName_jLabel = new javax.swing.JLabel();
        Update_jButton = new javax.swing.JButton();
        clear_jButton = new javax.swing.JButton();
        CourseCode_jLabel1 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        Add_jButton1 = new javax.swing.JButton();
        Delete_jButton1 = new javax.swing.JButton();
        jTextField4 = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        CourseInformation_jLabel1 = new javax.swing.JLabel();
        CourseCode_jLabel = new javax.swing.JLabel();
        CourseCode_jLabel2 = new javax.swing.JLabel();
        CourseCode_jLabel3 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jComboBox1 = new javax.swing.JComboBox<>();
        Add_jButton = new javax.swing.JButton();
        Delete_jButton = new javax.swing.JButton();
        back_jlabel = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("COURSE IFORMATION FORM");
        setBackground(new java.awt.Color(255, 255, 255));
        setBounds(new java.awt.Rectangle(0, 0, 0, 0));
        setFocusCycleRoot(false);
        setFocusable(false);
        setMinimumSize(new java.awt.Dimension(718, 364));
        setResizable(false);
        setSize(new java.awt.Dimension(718, 364));
        getContentPane().setLayout(null);

        CourseInformation_jLabel.setFont(new java.awt.Font("Buxton Sketch", 0, 36)); // NOI18N
        CourseInformation_jLabel.setForeground(new java.awt.Color(102, 102, 102));
        CourseInformation_jLabel.setText("DEPARTMENTS");
        getContentPane().add(CourseInformation_jLabel);
        CourseInformation_jLabel.setBounds(310, 40, 210, 27);

        Home_jButton.setBackground(new java.awt.Color(102, 102, 102));
        Home_jButton.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        Home_jButton.setForeground(new java.awt.Color(102, 102, 102));
        Home_jButton.setText("HOME");
        Home_jButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        Home_jButton.setMaximumSize(new java.awt.Dimension(100, 25));
        Home_jButton.setMinimumSize(new java.awt.Dimension(100, 25));
        Home_jButton.setOpaque(false);
        Home_jButton.setPreferredSize(new java.awt.Dimension(100, 25));
        Home_jButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Home_jButtonActionPerformed(evt);
            }
        });
        getContentPane().add(Home_jButton);
        Home_jButton.setBounds(280, 310, 100, 25);

        Course_jPanel.setBackground(new java.awt.Color(204, 204, 204));
        Course_jPanel.setForeground(new java.awt.Color(102, 102, 0));
        Course_jPanel.setOpaque(false);
        Course_jPanel.setLayout(null);

        CourseName_jLabel.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        CourseName_jLabel.setForeground(new java.awt.Color(102, 102, 102));
        CourseName_jLabel.setText("TEACHER NAME");
        CourseName_jLabel.setPreferredSize(new java.awt.Dimension(145, 20));
        Course_jPanel.add(CourseName_jLabel);
        CourseName_jLabel.setBounds(10, 110, 145, 20);

        Update_jButton.setBackground(new java.awt.Color(102, 102, 102));
        Update_jButton.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        Update_jButton.setForeground(new java.awt.Color(102, 102, 102));
        Update_jButton.setText("UPDATE");
        Update_jButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        Update_jButton.setMaximumSize(new java.awt.Dimension(300, 300));
        Update_jButton.setMinimumSize(new java.awt.Dimension(300, 300));
        Update_jButton.setOpaque(false);
        Update_jButton.setPreferredSize(new java.awt.Dimension(300, 300));
        Update_jButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Update_jButtonActionPerformed(evt);
            }
        });
        Course_jPanel.add(Update_jButton);
        Update_jButton.setBounds(140, 220, 100, 25);

        clear_jButton.setBackground(new java.awt.Color(102, 102, 102));
        clear_jButton.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        clear_jButton.setForeground(new java.awt.Color(102, 102, 102));
        clear_jButton.setText("CLEAR");
        clear_jButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        clear_jButton.setMaximumSize(new java.awt.Dimension(100, 25));
        clear_jButton.setMinimumSize(new java.awt.Dimension(100, 25));
        clear_jButton.setOpaque(false);
        clear_jButton.setPreferredSize(new java.awt.Dimension(100, 25));
        clear_jButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clear_jButtonActionPerformed(evt);
            }
        });
        Course_jPanel.add(clear_jButton);
        clear_jButton.setBounds(140, 250, 100, 25);

        CourseCode_jLabel1.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        CourseCode_jLabel1.setForeground(new java.awt.Color(153, 153, 153));
        CourseCode_jLabel1.setText("TEACHER ID");
        CourseCode_jLabel1.setPreferredSize(new java.awt.Dimension(145, 20));
        Course_jPanel.add(CourseCode_jLabel1);
        CourseCode_jLabel1.setBounds(10, 60, 145, 20);

        jTextField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField2ActionPerformed(evt);
            }
        });
        Course_jPanel.add(jTextField2);
        jTextField2.setBounds(140, 50, 130, 30);

        Add_jButton1.setBackground(new java.awt.Color(102, 102, 102));
        Add_jButton1.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        Add_jButton1.setForeground(new java.awt.Color(102, 102, 102));
        Add_jButton1.setText("ADD");
        Add_jButton1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        Add_jButton1.setMaximumSize(new java.awt.Dimension(300, 300));
        Add_jButton1.setMinimumSize(new java.awt.Dimension(300, 300));
        Add_jButton1.setOpaque(false);
        Add_jButton1.setPreferredSize(new java.awt.Dimension(300, 300));
        Add_jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Add_jButton1ActionPerformed(evt);
            }
        });
        Course_jPanel.add(Add_jButton1);
        Add_jButton1.setBounds(20, 220, 100, 25);

        Delete_jButton1.setBackground(new java.awt.Color(102, 102, 102));
        Delete_jButton1.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        Delete_jButton1.setForeground(new java.awt.Color(102, 102, 102));
        Delete_jButton1.setText("DELETE");
        Delete_jButton1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        Delete_jButton1.setMaximumSize(new java.awt.Dimension(100, 25));
        Delete_jButton1.setMinimumSize(new java.awt.Dimension(100, 25));
        Delete_jButton1.setOpaque(false);
        Delete_jButton1.setPreferredSize(new java.awt.Dimension(100, 25));
        Delete_jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Delete_jButton1ActionPerformed(evt);
            }
        });
        Course_jPanel.add(Delete_jButton1);
        Delete_jButton1.setBounds(20, 250, 100, 25);

        jTextField4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField4ActionPerformed(evt);
            }
        });
        Course_jPanel.add(jTextField4);
        jTextField4.setBounds(140, 100, 130, 30);

        getContentPane().add(Course_jPanel);
        Course_jPanel.setBounds(-10, 60, 270, 290);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Faculty Name", "Program"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(550, 170, 170, 190);

        CourseInformation_jLabel1.setFont(new java.awt.Font("Buxton Sketch", 0, 36)); // NOI18N
        CourseInformation_jLabel1.setForeground(new java.awt.Color(102, 102, 102));
        CourseInformation_jLabel1.setText("TEACHER");
        getContentPane().add(CourseInformation_jLabel1);
        CourseInformation_jLabel1.setBounds(60, 40, 140, 27);

        CourseCode_jLabel.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        CourseCode_jLabel.setForeground(new java.awt.Color(102, 102, 102));
        CourseCode_jLabel.setText("PROGRAM NAME");
        CourseCode_jLabel.setPreferredSize(new java.awt.Dimension(145, 20));
        getContentPane().add(CourseCode_jLabel);
        CourseCode_jLabel.setBounds(270, 210, 140, 20);

        CourseCode_jLabel2.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        CourseCode_jLabel2.setForeground(new java.awt.Color(102, 102, 102));
        CourseCode_jLabel2.setText("FACULTY NAME");
        CourseCode_jLabel2.setPreferredSize(new java.awt.Dimension(145, 20));
        getContentPane().add(CourseCode_jLabel2);
        CourseCode_jLabel2.setBounds(270, 110, 145, 20);

        CourseCode_jLabel3.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        CourseCode_jLabel3.setForeground(new java.awt.Color(102, 102, 102));
        CourseCode_jLabel3.setText("PROGRAM ID");
        CourseCode_jLabel3.setPreferredSize(new java.awt.Dimension(145, 20));
        getContentPane().add(CourseCode_jLabel3);
        CourseCode_jLabel3.setBounds(270, 160, 145, 20);

        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField1);
        jTextField1.setBounds(420, 160, 130, 30);

        jTextField3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField3ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField3);
        jTextField3.setBounds(420, 210, 130, 30);

        jComboBox1.setForeground(new java.awt.Color(102, 102, 102));
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Management Science", "Computer Science", " ", " " }));
        getContentPane().add(jComboBox1);
        jComboBox1.setBounds(420, 110, 130, 30);

        Add_jButton.setBackground(new java.awt.Color(102, 102, 102));
        Add_jButton.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        Add_jButton.setForeground(new java.awt.Color(102, 102, 102));
        Add_jButton.setText("ADD");
        Add_jButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        Add_jButton.setMaximumSize(new java.awt.Dimension(300, 300));
        Add_jButton.setMinimumSize(new java.awt.Dimension(300, 300));
        Add_jButton.setOpaque(false);
        Add_jButton.setPreferredSize(new java.awt.Dimension(300, 300));
        Add_jButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Add_jButtonActionPerformed(evt);
            }
        });
        getContentPane().add(Add_jButton);
        Add_jButton.setBounds(440, 280, 100, 25);

        Delete_jButton.setBackground(new java.awt.Color(102, 102, 102));
        Delete_jButton.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        Delete_jButton.setForeground(new java.awt.Color(102, 102, 102));
        Delete_jButton.setText("DELETE");
        Delete_jButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        Delete_jButton.setMaximumSize(new java.awt.Dimension(100, 25));
        Delete_jButton.setMinimumSize(new java.awt.Dimension(100, 25));
        Delete_jButton.setOpaque(false);
        Delete_jButton.setPreferredSize(new java.awt.Dimension(100, 25));
        Delete_jButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Delete_jButtonActionPerformed(evt);
            }
        });
        getContentPane().add(Delete_jButton);
        Delete_jButton.setBounds(440, 310, 100, 25);

        back_jlabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Student-ResourcesSmall.jpg"))); // NOI18N
        getContentPane().add(back_jlabel);
        back_jlabel.setBounds(0, 0, 550, 360);

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Teacher ID", "Teacher Name"
            }
        ));
        jScrollPane2.setViewportView(jTable2);

        getContentPane().add(jScrollPane2);
        jScrollPane2.setBounds(550, 0, 170, 170);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void Add_jButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Add_jButtonActionPerformed
        
    }//GEN-LAST:event_Add_jButtonActionPerformed

    private void Home_jButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Home_jButtonActionPerformed
        HOME h = new HOME();
        h.setVisible(true);
        dispose();
    }//GEN-LAST:event_Home_jButtonActionPerformed

    private void Delete_jButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Delete_jButtonActionPerformed
       
    }//GEN-LAST:event_Delete_jButtonActionPerformed

    private void Update_jButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Update_jButtonActionPerformed
            
       
        
      
        
      
    }//GEN-LAST:event_Update_jButtonActionPerformed

    private void clear_jButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clear_jButtonActionPerformed

       
    }//GEN-LAST:event_clear_jButtonActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jTextField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField2ActionPerformed

    private void jTextField3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField3ActionPerformed

    private void Add_jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Add_jButton1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Add_jButton1ActionPerformed

    private void Delete_jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Delete_jButton1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Delete_jButton1ActionPerformed

    private void jTextField4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField4ActionPerformed

    public static void main(String args[]) 
    {
        java.awt.EventQueue.invokeLater(new Runnable() 
        {
            public void run()
            {
                new SessionForm().setVisible(true);
            }
        });
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Add_jButton;
    private javax.swing.JButton Add_jButton1;
    private javax.swing.JLabel CourseCode_jLabel;
    private javax.swing.JLabel CourseCode_jLabel1;
    private javax.swing.JLabel CourseCode_jLabel2;
    private javax.swing.JLabel CourseCode_jLabel3;
    private javax.swing.JLabel CourseInformation_jLabel;
    private javax.swing.JLabel CourseInformation_jLabel1;
    private javax.swing.JLabel CourseName_jLabel;
    private javax.swing.JPanel Course_jPanel;
    private javax.swing.JButton Delete_jButton;
    private javax.swing.JButton Delete_jButton1;
    private javax.swing.JButton Home_jButton;
    private javax.swing.JButton Update_jButton;
    private javax.swing.JLabel back_jlabel;
    private javax.swing.JButton clear_jButton;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    // End of variables declaration//GEN-END:variables
}
