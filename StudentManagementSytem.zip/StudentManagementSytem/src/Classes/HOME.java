
package Classes;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import javazoom.jl.decoder.JavaLayerException;
import javazoom.jl.player.Player;

public class HOME extends javax.swing.JFrame 
{
    public HOME() 
    {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        studentinfo_jButton = new javax.swing.JButton();
        OverallResult_jButton = new javax.swing.JButton();
        CourseAllocation_jButton = new javax.swing.JButton();
        sessionForm_jButton = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        Examination_jButton2 = new javax.swing.JButton();
        IndividualResult_jButton1 = new javax.swing.JButton();
        CourseForm_jButton3 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("WELCOME TO HOME");
        setMinimumSize(new java.awt.Dimension(685, 465));
        setResizable(false);
        setSize(new java.awt.Dimension(685, 465));

        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.setMaximumSize(new java.awt.Dimension(685, 465));
        jPanel1.setMinimumSize(new java.awt.Dimension(685, 465));
        jPanel1.setPreferredSize(new java.awt.Dimension(685, 465));
        jPanel1.setLayout(null);

        jLabel3.setFont(new java.awt.Font("Buxton Sketch", 1, 36)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("HOME PAGE");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(240, 70, 180, 45);

        studentinfo_jButton.setBackground(new java.awt.Color(102, 102, 102));
        studentinfo_jButton.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        studentinfo_jButton.setForeground(new java.awt.Color(255, 255, 255));
        studentinfo_jButton.setText("STUDENT INFORMATION");
        studentinfo_jButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        studentinfo_jButton.setOpaque(false);
        studentinfo_jButton.setPreferredSize(new java.awt.Dimension(215, 30));
        studentinfo_jButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                studentinfo_jButtonActionPerformed(evt);
            }
        });
        jPanel1.add(studentinfo_jButton);
        studentinfo_jButton.setBounds(80, 180, 215, 30);

        OverallResult_jButton.setBackground(new java.awt.Color(102, 102, 102));
        OverallResult_jButton.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        OverallResult_jButton.setForeground(new java.awt.Color(255, 255, 255));
        OverallResult_jButton.setText("OVERALL RESULT");
        OverallResult_jButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        OverallResult_jButton.setOpaque(false);
        OverallResult_jButton.setPreferredSize(new java.awt.Dimension(215, 30));
        OverallResult_jButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                OverallResult_jButtonActionPerformed(evt);
            }
        });
        jPanel1.add(OverallResult_jButton);
        OverallResult_jButton.setBounds(80, 240, 215, 30);

        CourseAllocation_jButton.setBackground(new java.awt.Color(102, 102, 102));
        CourseAllocation_jButton.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        CourseAllocation_jButton.setForeground(new java.awt.Color(255, 255, 255));
        CourseAllocation_jButton.setText("COURSE ALLOCATION");
        CourseAllocation_jButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        CourseAllocation_jButton.setOpaque(false);
        CourseAllocation_jButton.setPreferredSize(new java.awt.Dimension(215, 30));
        CourseAllocation_jButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CourseAllocation_jButtonActionPerformed(evt);
            }
        });
        jPanel1.add(CourseAllocation_jButton);
        CourseAllocation_jButton.setBounds(220, 330, 215, 30);

        sessionForm_jButton.setBackground(new java.awt.Color(102, 102, 102));
        sessionForm_jButton.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        sessionForm_jButton.setForeground(new java.awt.Color(255, 255, 255));
        sessionForm_jButton.setText("SESSION FORM");
        sessionForm_jButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        sessionForm_jButton.setOpaque(false);
        sessionForm_jButton.setPreferredSize(new java.awt.Dimension(215, 30));
        sessionForm_jButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sessionForm_jButtonActionPerformed(evt);
            }
        });
        jPanel1.add(sessionForm_jButton);
        sessionForm_jButton.setBounds(340, 180, 215, 30);

        jButton1.setBackground(new java.awt.Color(102, 102, 102));
        jButton1.setFont(new java.awt.Font("Buxton Sketch", 1, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("LOGOUT");
        jButton1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton1.setOpaque(false);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1);
        jButton1.setBounds(280, 400, 90, 21);

        Examination_jButton2.setBackground(new java.awt.Color(102, 102, 102));
        Examination_jButton2.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        Examination_jButton2.setForeground(new java.awt.Color(255, 255, 255));
        Examination_jButton2.setText("EXAMINATION");
        Examination_jButton2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        Examination_jButton2.setOpaque(false);
        Examination_jButton2.setPreferredSize(new java.awt.Dimension(215, 30));
        Examination_jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Examination_jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(Examination_jButton2);
        Examination_jButton2.setBounds(80, 290, 215, 30);

        IndividualResult_jButton1.setBackground(new java.awt.Color(102, 102, 102));
        IndividualResult_jButton1.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        IndividualResult_jButton1.setForeground(new java.awt.Color(255, 255, 255));
        IndividualResult_jButton1.setText("INDIVIDUAL RESULT");
        IndividualResult_jButton1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        IndividualResult_jButton1.setOpaque(false);
        IndividualResult_jButton1.setPreferredSize(new java.awt.Dimension(215, 30));
        IndividualResult_jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                IndividualResult_jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(IndividualResult_jButton1);
        IndividualResult_jButton1.setBounds(340, 240, 215, 30);

        CourseForm_jButton3.setBackground(new java.awt.Color(102, 102, 102));
        CourseForm_jButton3.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        CourseForm_jButton3.setForeground(new java.awt.Color(255, 255, 255));
        CourseForm_jButton3.setText("COURSE FORM");
        CourseForm_jButton3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        CourseForm_jButton3.setOpaque(false);
        CourseForm_jButton3.setPreferredSize(new java.awt.Dimension(215, 30));
        CourseForm_jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CourseForm_jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(CourseForm_jButton3);
        CourseForm_jButton3.setBounds(340, 290, 215, 30);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/school-design-architecture-unique-school-design-architecture-of-school-design-architecture.jpg"))); // NOI18N
        jLabel1.setMaximumSize(new java.awt.Dimension(685, 465));
        jLabel1.setMinimumSize(new java.awt.Dimension(685, 465));
        jLabel1.setPreferredSize(new java.awt.Dimension(685, 465));
        jPanel1.add(jLabel1);
        jLabel1.setBounds(0, 0, 680, 465);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 685, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void OverallResult_jButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_OverallResult_jButtonActionPerformed
       Result_Form kl = new Result_Form();
        kl.setVisible(true);
        dispose();
    }//GEN-LAST:event_OverallResult_jButtonActionPerformed

    private void studentinfo_jButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_studentinfo_jButtonActionPerformed
        StudentInformation sif = new StudentInformation();
        sif.setVisible(true);
        dispose();
    }//GEN-LAST:event_studentinfo_jButtonActionPerformed

    private void sessionForm_jButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sessionForm_jButtonActionPerformed
        SessionForm ac = new SessionForm();
        ac.setVisible(true);
        dispose();
    }//GEN-LAST:event_sessionForm_jButtonActionPerformed

    private void CourseAllocation_jButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CourseAllocation_jButtonActionPerformed
        COURSE_ALLOCATIONFORM xc = new COURSE_ALLOCATIONFORM();
        xc.setVisible(true);
        dispose();
    }//GEN-LAST:event_CourseAllocation_jButtonActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
               
        LoginForm lf = new LoginForm();
        lf.setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void IndividualResult_jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_IndividualResult_jButton1ActionPerformed
       Individual_Result pf = new Individual_Result();
        pf.setVisible(true);
        dispose(); // TODO add your handling code here:
    }//GEN-LAST:event_IndividualResult_jButton1ActionPerformed

    private void Examination_jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Examination_jButton2ActionPerformed
        Examination df = new Examination();
        df.setVisible(true);
        dispose();// TODO add your handling code here:
    }//GEN-LAST:event_Examination_jButton2ActionPerformed

    private void CourseForm_jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CourseForm_jButton3ActionPerformed
        CourseForm lf = new CourseForm();
        lf.setVisible(true);
        dispose();// TODO add your handling code here:
    }//GEN-LAST:event_CourseForm_jButton3ActionPerformed

    public static void main(String args[])
    {
        java.awt.EventQueue.invokeLater(new Runnable() 
        {
            public void run()
            {
                new HOME().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton CourseAllocation_jButton;
    private javax.swing.JButton CourseForm_jButton3;
    private javax.swing.JButton Examination_jButton2;
    private javax.swing.JButton IndividualResult_jButton1;
    private javax.swing.JButton OverallResult_jButton;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton sessionForm_jButton;
    private javax.swing.JButton studentinfo_jButton;
    // End of variables declaration//GEN-END:variables
}
