
package Classes;
import com.sun.glass.events.KeyEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class COURSE_ALLOCATIONFORM extends javax.swing.JFrame
{
    Connect connect = new Connect();
   
    public COURSE_ALLOCATIONFORM()
    {
        initComponents();
        connect.Connect();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Home_jButton = new javax.swing.JButton();
        Course_jPanel = new javax.swing.JPanel();
        Year = new javax.swing.JLabel();
        clear_jButton = new javax.swing.JButton();
        student_ID = new javax.swing.JLabel();
        ProgramIDtext = new javax.swing.JTextField();
        Delete_jButton1 = new javax.swing.JButton();
        Teacher_IDtext = new javax.swing.JTextField();
        sessioncombo = new javax.swing.JComboBox<>();
        Sessioncombo = new javax.swing.JComboBox<>();
        Teacher_ID = new javax.swing.JLabel();
        Session = new javax.swing.JLabel();
        ProgramID = new javax.swing.JLabel();
        Student_IDtext = new javax.swing.JTextField();
        CourseCode_jLabel2 = new javax.swing.JLabel();
        Course_Codetext = new javax.swing.JTextField();
        CourseInformation_jLabel1 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        Update_jButton = new javax.swing.JButton();
        Add_jButton1 = new javax.swing.JButton();
        back_jlabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("COURSE IFORMATION FORM");
        setBackground(new java.awt.Color(255, 255, 255));
        setBounds(new java.awt.Rectangle(0, 0, 0, 0));
        setFocusCycleRoot(false);
        setFocusable(false);
        setMinimumSize(new java.awt.Dimension(718, 364));
        setResizable(false);
        setSize(new java.awt.Dimension(718, 364));
        getContentPane().setLayout(null);

        Home_jButton.setBackground(new java.awt.Color(102, 102, 102));
        Home_jButton.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        Home_jButton.setForeground(new java.awt.Color(102, 102, 102));
        Home_jButton.setText("HOME");
        Home_jButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        Home_jButton.setMaximumSize(new java.awt.Dimension(100, 25));
        Home_jButton.setMinimumSize(new java.awt.Dimension(100, 25));
        Home_jButton.setOpaque(false);
        Home_jButton.setPreferredSize(new java.awt.Dimension(100, 25));
        Home_jButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Home_jButtonActionPerformed(evt);
            }
        });
        getContentPane().add(Home_jButton);
        Home_jButton.setBounds(490, 290, 100, 25);

        Course_jPanel.setBackground(new java.awt.Color(204, 204, 204));
        Course_jPanel.setForeground(new java.awt.Color(102, 102, 0));
        Course_jPanel.setOpaque(false);
        Course_jPanel.setLayout(null);

        Year.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        Year.setText("YEAR");
        Year.setPreferredSize(new java.awt.Dimension(145, 20));
        Course_jPanel.add(Year);
        Year.setBounds(20, 170, 145, 20);

        clear_jButton.setBackground(new java.awt.Color(102, 102, 102));
        clear_jButton.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        clear_jButton.setForeground(new java.awt.Color(102, 102, 102));
        clear_jButton.setText("CLEAR");
        clear_jButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        clear_jButton.setMaximumSize(new java.awt.Dimension(100, 25));
        clear_jButton.setMinimumSize(new java.awt.Dimension(100, 25));
        clear_jButton.setOpaque(false);
        clear_jButton.setPreferredSize(new java.awt.Dimension(100, 25));
        clear_jButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clear_jButtonActionPerformed(evt);
            }
        });
        Course_jPanel.add(clear_jButton);
        clear_jButton.setBounds(140, 240, 100, 25);

        student_ID.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        student_ID.setText("STUDENT ID");
        student_ID.setPreferredSize(new java.awt.Dimension(145, 20));
        Course_jPanel.add(student_ID);
        student_ID.setBounds(20, 0, 145, 20);

        ProgramIDtext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ProgramIDtextActionPerformed(evt);
            }
        });
        Course_jPanel.add(ProgramIDtext);
        ProgramIDtext.setBounds(140, 200, 130, 30);

        Delete_jButton1.setBackground(new java.awt.Color(102, 102, 102));
        Delete_jButton1.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        Delete_jButton1.setForeground(new java.awt.Color(102, 102, 102));
        Delete_jButton1.setText("DELETE");
        Delete_jButton1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        Delete_jButton1.setMaximumSize(new java.awt.Dimension(100, 25));
        Delete_jButton1.setMinimumSize(new java.awt.Dimension(100, 25));
        Delete_jButton1.setOpaque(false);
        Delete_jButton1.setPreferredSize(new java.awt.Dimension(100, 25));
        Delete_jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Delete_jButton1ActionPerformed(evt);
            }
        });
        Course_jPanel.add(Delete_jButton1);
        Delete_jButton1.setBounds(20, 240, 100, 25);

        Teacher_IDtext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Teacher_IDtextActionPerformed(evt);
            }
        });
        Course_jPanel.add(Teacher_IDtext);
        Teacher_IDtext.setBounds(140, 80, 130, 30);

        sessioncombo.setForeground(new java.awt.Color(102, 102, 102));
        sessioncombo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "2015", "2016", "2017", "2018" }));
        Course_jPanel.add(sessioncombo);
        sessioncombo.setBounds(140, 160, 130, 30);

        Sessioncombo.setForeground(new java.awt.Color(102, 102, 102));
        Sessioncombo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "FALL", "SPRING", " " }));
        Course_jPanel.add(Sessioncombo);
        Sessioncombo.setBounds(140, 120, 130, 30);

        Teacher_ID.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        Teacher_ID.setText("TEACHER ID");
        Teacher_ID.setPreferredSize(new java.awt.Dimension(145, 20));
        Course_jPanel.add(Teacher_ID);
        Teacher_ID.setBounds(20, 90, 145, 20);

        Session.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        Session.setText("SESSION");
        Session.setPreferredSize(new java.awt.Dimension(145, 20));
        Course_jPanel.add(Session);
        Session.setBounds(20, 130, 145, 20);

        ProgramID.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        ProgramID.setText("PROGRAM ID");
        ProgramID.setPreferredSize(new java.awt.Dimension(145, 20));
        Course_jPanel.add(ProgramID);
        ProgramID.setBounds(20, 200, 145, 20);

        Student_IDtext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Student_IDtextActionPerformed(evt);
            }
        });
        Course_jPanel.add(Student_IDtext);
        Student_IDtext.setBounds(140, 0, 130, 30);

        CourseCode_jLabel2.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        CourseCode_jLabel2.setText("COURSE CODE");
        CourseCode_jLabel2.setPreferredSize(new java.awt.Dimension(145, 20));
        Course_jPanel.add(CourseCode_jLabel2);
        CourseCode_jLabel2.setBounds(20, 50, 145, 20);

        Course_Codetext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Course_CodetextActionPerformed(evt);
            }
        });
        Course_jPanel.add(Course_Codetext);
        Course_Codetext.setBounds(140, 40, 130, 30);

        getContentPane().add(Course_jPanel);
        Course_jPanel.setBounds(-10, 50, 270, 310);

        CourseInformation_jLabel1.setFont(new java.awt.Font("Buxton Sketch", 0, 36)); // NOI18N
        CourseInformation_jLabel1.setText("COURSE ALLOCATION");
        getContentPane().add(CourseInformation_jLabel1);
        CourseInformation_jLabel1.setBounds(200, 10, 290, 27);

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Course Code", "Teacher ID", "Session", "Year", "Program ID", "Student ID"
            }
        ));
        jScrollPane2.setViewportView(jTable2);

        getContentPane().add(jScrollPane2);
        jScrollPane2.setBounds(342, 50, 380, 220);

        Update_jButton.setBackground(new java.awt.Color(102, 102, 102));
        Update_jButton.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        Update_jButton.setForeground(new java.awt.Color(102, 102, 102));
        Update_jButton.setText("UPDATE");
        Update_jButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        Update_jButton.setMaximumSize(new java.awt.Dimension(300, 300));
        Update_jButton.setMinimumSize(new java.awt.Dimension(300, 300));
        Update_jButton.setOpaque(false);
        Update_jButton.setPreferredSize(new java.awt.Dimension(300, 300));
        Update_jButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Update_jButtonActionPerformed(evt);
            }
        });
        getContentPane().add(Update_jButton);
        Update_jButton.setBounds(600, 290, 100, 25);

        Add_jButton1.setBackground(new java.awt.Color(255, 255, 255));
        Add_jButton1.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        Add_jButton1.setForeground(new java.awt.Color(102, 102, 102));
        Add_jButton1.setText("ADD");
        Add_jButton1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        Add_jButton1.setMaximumSize(new java.awt.Dimension(300, 300));
        Add_jButton1.setMinimumSize(new java.awt.Dimension(300, 300));
        Add_jButton1.setOpaque(false);
        Add_jButton1.setPreferredSize(new java.awt.Dimension(300, 300));
        Add_jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Add_jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(Add_jButton1);
        Add_jButton1.setBounds(350, 290, 100, 25);

        back_jlabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/PROJECT5.png"))); // NOI18N
        getContentPane().add(back_jlabel);
        back_jlabel.setBounds(-10, -60, 720, 560);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void Home_jButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Home_jButtonActionPerformed
        HOME h = new HOME();
        h.setVisible(true);
        dispose();
    }//GEN-LAST:event_Home_jButtonActionPerformed

    private void Update_jButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Update_jButtonActionPerformed
            
       
        
      
    }//GEN-LAST:event_Update_jButtonActionPerformed

    private void clear_jButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clear_jButtonActionPerformed

       
       
    }//GEN-LAST:event_clear_jButtonActionPerformed

    private void ProgramIDtextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ProgramIDtextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ProgramIDtextActionPerformed

    private void Add_jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Add_jButton1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Add_jButton1ActionPerformed

    private void Delete_jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Delete_jButton1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Delete_jButton1ActionPerformed

    private void Teacher_IDtextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Teacher_IDtextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Teacher_IDtextActionPerformed

    private void Student_IDtextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Student_IDtextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Student_IDtextActionPerformed

    private void Course_CodetextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Course_CodetextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Course_CodetextActionPerformed

    public static void main(String args[]) 
    {
        java.awt.EventQueue.invokeLater(new Runnable() 
        {
            public void run()
            {
                new COURSE_ALLOCATIONFORM().setVisible(true);
            }
        });
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Add_jButton1;
    private javax.swing.JLabel CourseCode_jLabel2;
    private javax.swing.JLabel CourseInformation_jLabel1;
    private javax.swing.JTextField Course_Codetext;
    private javax.swing.JPanel Course_jPanel;
    private javax.swing.JButton Delete_jButton1;
    private javax.swing.JButton Home_jButton;
    private javax.swing.JLabel ProgramID;
    private javax.swing.JTextField ProgramIDtext;
    private javax.swing.JLabel Session;
    private javax.swing.JComboBox<String> Sessioncombo;
    private javax.swing.JTextField Student_IDtext;
    private javax.swing.JLabel Teacher_ID;
    private javax.swing.JTextField Teacher_IDtext;
    private javax.swing.JButton Update_jButton;
    private javax.swing.JLabel Year;
    private javax.swing.JLabel back_jlabel;
    private javax.swing.JButton clear_jButton;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable2;
    private javax.swing.JComboBox<String> sessioncombo;
    private javax.swing.JLabel student_ID;
    // End of variables declaration//GEN-END:variables
}
