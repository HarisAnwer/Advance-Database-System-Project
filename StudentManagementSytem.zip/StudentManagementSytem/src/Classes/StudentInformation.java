package Classes;
import com.sun.glass.events.KeyEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.ButtonGroup;
import javax.swing.JOptionPane;
public class StudentInformation extends javax.swing.JFrame
{
    Connect connect = new Connect();
    
     
    public StudentInformation() 
    {
        initComponents();
        connect.Connect();
        
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jSplitPane1 = new javax.swing.JSplitPane();
        StudentInformation_jLabel = new javax.swing.JLabel();
        search_jTextField = new javax.swing.JTextField();
        CourseFee_jLabel1 = new javax.swing.JLabel();
        CourseFee_jLabel2 = new javax.swing.JLabel();
        CourseFee_jLabel3 = new javax.swing.JLabel();
        CourseFee_jLabel4 = new javax.swing.JLabel();
        CourseFee_jLabel5 = new javax.swing.JLabel();
        CourseFee_jLabel6 = new javax.swing.JLabel();
        CourseFee_jLabel7 = new javax.swing.JLabel();
        CourseFee_jLabel8 = new javax.swing.JLabel();
        CourseFee_jLabel9 = new javax.swing.JLabel();
        CourseFee_jLabel10 = new javax.swing.JLabel();
        CourseFee_jLabel11 = new javax.swing.JLabel();
        CourseFee_jLabel12 = new javax.swing.JLabel();
        CourseFee_jLabel13 = new javax.swing.JLabel();
        CourseFee_jLabel14 = new javax.swing.JLabel();
        Home_jButton = new javax.swing.JButton();
        clear_jButton = new javax.swing.JButton();
        Update_jButton = new javax.swing.JButton();
        Delete_jButton = new javax.swing.JButton();
        Add_jButton = new javax.swing.JButton();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jTextField1 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jTextField5 = new javax.swing.JTextField();
        jTextField6 = new javax.swing.JTextField();
        jTextField7 = new javax.swing.JTextField();
        jTextField8 = new javax.swing.JTextField();
        jComboBox4 = new javax.swing.JComboBox<>();
        jComboBox1 = new javax.swing.JComboBox<>();
        jTextField9 = new javax.swing.JTextField();
        jComboBox2 = new javax.swing.JComboBox<>();
        jComboBox3 = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        mainback_jLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("STUDENT INFORMATION");
        setMinimumSize(new java.awt.Dimension(914, 552));
        setResizable(false);
        setSize(new java.awt.Dimension(914, 552));
        getContentPane().setLayout(null);

        StudentInformation_jLabel.setFont(new java.awt.Font("Buxton Sketch", 1, 36)); // NOI18N
        StudentInformation_jLabel.setForeground(new java.awt.Color(102, 102, 102));
        StudentInformation_jLabel.setText("STUDENT INFORMATION");
        getContentPane().add(StudentInformation_jLabel);
        StudentInformation_jLabel.setBounds(250, 0, 358, 45);

        search_jTextField.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        search_jTextField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        search_jTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                search_jTextFieldActionPerformed(evt);
            }
        });
        search_jTextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                search_jTextFieldKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                search_jTextFieldKeyReleased(evt);
            }
        });
        getContentPane().add(search_jTextField);
        search_jTextField.setBounds(780, 20, 117, 19);

        CourseFee_jLabel1.setBackground(new java.awt.Color(0, 0, 0));
        CourseFee_jLabel1.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        CourseFee_jLabel1.setForeground(new java.awt.Color(102, 102, 102));
        CourseFee_jLabel1.setText("Phone No");
        CourseFee_jLabel1.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        CourseFee_jLabel1.setPreferredSize(new java.awt.Dimension(145, 20));
        getContentPane().add(CourseFee_jLabel1);
        CourseFee_jLabel1.setBounds(40, 250, 130, 20);

        CourseFee_jLabel2.setBackground(new java.awt.Color(0, 0, 0));
        CourseFee_jLabel2.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        CourseFee_jLabel2.setForeground(new java.awt.Color(102, 102, 102));
        CourseFee_jLabel2.setText("SEARCH");
        CourseFee_jLabel2.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        CourseFee_jLabel2.setPreferredSize(new java.awt.Dimension(145, 20));
        getContentPane().add(CourseFee_jLabel2);
        CourseFee_jLabel2.setBounds(680, 20, 66, 20);

        CourseFee_jLabel3.setBackground(new java.awt.Color(0, 0, 0));
        CourseFee_jLabel3.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        CourseFee_jLabel3.setForeground(new java.awt.Color(102, 102, 102));
        CourseFee_jLabel3.setText("Student ID");
        CourseFee_jLabel3.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        CourseFee_jLabel3.setPreferredSize(new java.awt.Dimension(145, 20));
        getContentPane().add(CourseFee_jLabel3);
        CourseFee_jLabel3.setBounds(40, 90, 100, 20);

        CourseFee_jLabel4.setBackground(new java.awt.Color(0, 0, 0));
        CourseFee_jLabel4.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        CourseFee_jLabel4.setForeground(new java.awt.Color(102, 102, 102));
        CourseFee_jLabel4.setText("Student Name");
        CourseFee_jLabel4.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        CourseFee_jLabel4.setPreferredSize(new java.awt.Dimension(145, 20));
        getContentPane().add(CourseFee_jLabel4);
        CourseFee_jLabel4.setBounds(40, 130, 130, 20);

        CourseFee_jLabel5.setBackground(new java.awt.Color(0, 0, 0));
        CourseFee_jLabel5.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        CourseFee_jLabel5.setForeground(new java.awt.Color(102, 102, 102));
        CourseFee_jLabel5.setText("Father Name");
        CourseFee_jLabel5.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        CourseFee_jLabel5.setPreferredSize(new java.awt.Dimension(145, 20));
        getContentPane().add(CourseFee_jLabel5);
        CourseFee_jLabel5.setBounds(40, 170, 130, 20);

        CourseFee_jLabel6.setBackground(new java.awt.Color(0, 0, 0));
        CourseFee_jLabel6.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        CourseFee_jLabel6.setForeground(new java.awt.Color(102, 102, 102));
        CourseFee_jLabel6.setText("Campus");
        CourseFee_jLabel6.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        CourseFee_jLabel6.setPreferredSize(new java.awt.Dimension(145, 20));
        getContentPane().add(CourseFee_jLabel6);
        CourseFee_jLabel6.setBounds(40, 50, 130, 20);

        CourseFee_jLabel7.setBackground(new java.awt.Color(0, 0, 0));
        CourseFee_jLabel7.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        CourseFee_jLabel7.setForeground(new java.awt.Color(102, 102, 102));
        CourseFee_jLabel7.setText("Date Of Birth");
        CourseFee_jLabel7.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        CourseFee_jLabel7.setPreferredSize(new java.awt.Dimension(145, 20));
        getContentPane().add(CourseFee_jLabel7);
        CourseFee_jLabel7.setBounds(40, 210, 130, 20);

        CourseFee_jLabel8.setBackground(new java.awt.Color(0, 0, 0));
        CourseFee_jLabel8.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        CourseFee_jLabel8.setForeground(new java.awt.Color(102, 102, 102));
        CourseFee_jLabel8.setText("Email");
        CourseFee_jLabel8.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        CourseFee_jLabel8.setPreferredSize(new java.awt.Dimension(145, 20));
        getContentPane().add(CourseFee_jLabel8);
        CourseFee_jLabel8.setBounds(40, 290, 130, 20);

        CourseFee_jLabel9.setBackground(new java.awt.Color(0, 0, 0));
        CourseFee_jLabel9.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        CourseFee_jLabel9.setForeground(new java.awt.Color(102, 102, 102));
        CourseFee_jLabel9.setText("Address");
        CourseFee_jLabel9.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        CourseFee_jLabel9.setPreferredSize(new java.awt.Dimension(145, 20));
        getContentPane().add(CourseFee_jLabel9);
        CourseFee_jLabel9.setBounds(40, 330, 130, 20);

        CourseFee_jLabel10.setBackground(new java.awt.Color(0, 0, 0));
        CourseFee_jLabel10.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        CourseFee_jLabel10.setForeground(new java.awt.Color(102, 102, 102));
        CourseFee_jLabel10.setText("Department");
        CourseFee_jLabel10.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        CourseFee_jLabel10.setPreferredSize(new java.awt.Dimension(145, 20));
        getContentPane().add(CourseFee_jLabel10);
        CourseFee_jLabel10.setBounds(40, 370, 130, 20);

        CourseFee_jLabel11.setBackground(new java.awt.Color(0, 0, 0));
        CourseFee_jLabel11.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        CourseFee_jLabel11.setForeground(new java.awt.Color(102, 102, 102));
        CourseFee_jLabel11.setText("Program ID");
        CourseFee_jLabel11.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        CourseFee_jLabel11.setPreferredSize(new java.awt.Dimension(145, 20));
        getContentPane().add(CourseFee_jLabel11);
        CourseFee_jLabel11.setBounds(40, 410, 130, 30);

        CourseFee_jLabel12.setBackground(new java.awt.Color(0, 0, 0));
        CourseFee_jLabel12.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        CourseFee_jLabel12.setForeground(new java.awt.Color(102, 102, 102));
        CourseFee_jLabel12.setText("HSSC %");
        CourseFee_jLabel12.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        CourseFee_jLabel12.setPreferredSize(new java.awt.Dimension(145, 20));
        getContentPane().add(CourseFee_jLabel12);
        CourseFee_jLabel12.setBounds(40, 450, 130, 20);

        CourseFee_jLabel13.setBackground(new java.awt.Color(0, 0, 0));
        CourseFee_jLabel13.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        CourseFee_jLabel13.setForeground(new java.awt.Color(102, 102, 102));
        CourseFee_jLabel13.setText("Session");
        CourseFee_jLabel13.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        CourseFee_jLabel13.setPreferredSize(new java.awt.Dimension(145, 20));
        getContentPane().add(CourseFee_jLabel13);
        CourseFee_jLabel13.setBounds(400, 90, 130, 20);

        CourseFee_jLabel14.setBackground(new java.awt.Color(0, 0, 0));
        CourseFee_jLabel14.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        CourseFee_jLabel14.setForeground(new java.awt.Color(102, 102, 102));
        CourseFee_jLabel14.setText("Year");
        CourseFee_jLabel14.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        CourseFee_jLabel14.setPreferredSize(new java.awt.Dimension(145, 20));
        getContentPane().add(CourseFee_jLabel14);
        CourseFee_jLabel14.setBounds(400, 50, 130, 20);

        Home_jButton.setBackground(new java.awt.Color(102, 102, 102));
        Home_jButton.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        Home_jButton.setText("HOME");
        Home_jButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        Home_jButton.setMaximumSize(new java.awt.Dimension(100, 25));
        Home_jButton.setMinimumSize(new java.awt.Dimension(100, 25));
        Home_jButton.setOpaque(false);
        Home_jButton.setPreferredSize(new java.awt.Dimension(100, 25));
        Home_jButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Home_jButtonActionPerformed(evt);
            }
        });
        getContentPane().add(Home_jButton);
        Home_jButton.setBounds(830, 440, 80, 25);

        clear_jButton.setBackground(new java.awt.Color(102, 102, 102));
        clear_jButton.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        clear_jButton.setText("CLEAR");
        clear_jButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        clear_jButton.setMaximumSize(new java.awt.Dimension(100, 25));
        clear_jButton.setMinimumSize(new java.awt.Dimension(100, 25));
        clear_jButton.setOpaque(false);
        clear_jButton.setPreferredSize(new java.awt.Dimension(100, 25));
        clear_jButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clear_jButtonActionPerformed(evt);
            }
        });
        getContentPane().add(clear_jButton);
        clear_jButton.setBounds(720, 440, 100, 25);

        Update_jButton.setBackground(new java.awt.Color(102, 102, 102));
        Update_jButton.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        Update_jButton.setText("UPDATE");
        Update_jButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        Update_jButton.setMaximumSize(new java.awt.Dimension(100, 25));
        Update_jButton.setMinimumSize(new java.awt.Dimension(100, 25));
        Update_jButton.setOpaque(false);
        Update_jButton.setPreferredSize(new java.awt.Dimension(100, 25));
        Update_jButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Update_jButtonActionPerformed(evt);
            }
        });
        getContentPane().add(Update_jButton);
        Update_jButton.setBounds(620, 440, 100, 25);

        Delete_jButton.setBackground(new java.awt.Color(102, 102, 102));
        Delete_jButton.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        Delete_jButton.setText("DELETE");
        Delete_jButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        Delete_jButton.setMaximumSize(new java.awt.Dimension(100, 25));
        Delete_jButton.setMinimumSize(new java.awt.Dimension(100, 25));
        Delete_jButton.setOpaque(false);
        Delete_jButton.setPreferredSize(new java.awt.Dimension(100, 25));
        Delete_jButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Delete_jButtonActionPerformed(evt);
            }
        });
        getContentPane().add(Delete_jButton);
        Delete_jButton.setBounds(510, 440, 100, 25);

        Add_jButton.setBackground(new java.awt.Color(102, 102, 102));
        Add_jButton.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        Add_jButton.setText("ADD");
        Add_jButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        Add_jButton.setMaximumSize(new java.awt.Dimension(100, 25));
        Add_jButton.setMinimumSize(new java.awt.Dimension(100, 25));
        Add_jButton.setOpaque(false);
        Add_jButton.setPreferredSize(new java.awt.Dimension(100, 25));
        Add_jButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Add_jButtonActionPerformed(evt);
            }
        });
        getContentPane().add(Add_jButton);
        Add_jButton.setBounds(400, 440, 100, 25);
        getContentPane().add(jTextField2);
        jTextField2.setBounds(160, 90, 210, 20);
        getContentPane().add(jTextField3);
        jTextField3.setBounds(160, 170, 210, 20);
        getContentPane().add(jTextField1);
        jTextField1.setBounds(160, 130, 210, 20);
        getContentPane().add(jTextField4);
        jTextField4.setBounds(160, 210, 210, 20);

        jTextField5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField5ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField5);
        jTextField5.setBounds(160, 250, 210, 20);

        jTextField6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField6ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField6);
        jTextField6.setBounds(160, 290, 210, 20);
        getContentPane().add(jTextField7);
        jTextField7.setBounds(160, 330, 210, 20);
        getContentPane().add(jTextField8);
        jTextField8.setBounds(160, 410, 210, 20);

        jComboBox4.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Karachi", "Islamabad" }));
        jComboBox4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox4ActionPerformed(evt);
            }
        });
        getContentPane().add(jComboBox4);
        jComboBox4.setBounds(160, 50, 210, 20);

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Fall", "Spring" }));
        getContentPane().add(jComboBox1);
        jComboBox1.setBounds(470, 90, 210, 20);
        getContentPane().add(jTextField9);
        jTextField9.setBounds(160, 450, 210, 20);

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "2015", "2016", "2017", "2018" }));
        getContentPane().add(jComboBox2);
        jComboBox2.setBounds(460, 50, 210, 20);

        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Management Science", "Computer Science" }));
        getContentPane().add(jComboBox3);
        jComboBox3.setBounds(160, 370, 210, 20);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Campus", "Student ID", "Program ID", "Year", "Session"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(390, 140, 520, 90);

        mainback_jLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/p02vdpfn.jpg"))); // NOI18N
        getContentPane().add(mainback_jLabel);
        mainback_jLabel.setBounds(0, 0, 910, 560);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void Home_jButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Home_jButtonActionPerformed
        HOME h = new HOME();
        h.setVisible(true);
        dispose();
    }//GEN-LAST:event_Home_jButtonActionPerformed

    private void Add_jButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Add_jButtonActionPerformed
        
        
    }//GEN-LAST:event_Add_jButtonActionPerformed

    private void Delete_jButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Delete_jButtonActionPerformed
        
        
    }//GEN-LAST:event_Delete_jButtonActionPerformed

    private void search_jTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_search_jTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_search_jTextFieldActionPerformed

    private void search_jTextFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_search_jTextFieldKeyReleased
       
       
    }//GEN-LAST:event_search_jTextFieldKeyReleased

    private void clear_jButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clear_jButtonActionPerformed
        
        
    }//GEN-LAST:event_clear_jButtonActionPerformed

    private void Update_jButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Update_jButtonActionPerformed
      
            
    }//GEN-LAST:event_Update_jButtonActionPerformed

    private void search_jTextFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_search_jTextFieldKeyPressed
        
    }//GEN-LAST:event_search_jTextFieldKeyPressed

    private void jTextField5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField5ActionPerformed

    private void jTextField6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField6ActionPerformed

    private void jComboBox4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox4ActionPerformed

    public static void main(String args[]) 
    {
        java.awt.EventQueue.invokeLater(new Runnable()
        {
            public void run() 
            {
                new StudentInformation().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Add_jButton;
    private javax.swing.JLabel CourseFee_jLabel1;
    private javax.swing.JLabel CourseFee_jLabel10;
    private javax.swing.JLabel CourseFee_jLabel11;
    private javax.swing.JLabel CourseFee_jLabel12;
    private javax.swing.JLabel CourseFee_jLabel13;
    private javax.swing.JLabel CourseFee_jLabel14;
    private javax.swing.JLabel CourseFee_jLabel2;
    private javax.swing.JLabel CourseFee_jLabel3;
    private javax.swing.JLabel CourseFee_jLabel4;
    private javax.swing.JLabel CourseFee_jLabel5;
    private javax.swing.JLabel CourseFee_jLabel6;
    private javax.swing.JLabel CourseFee_jLabel7;
    private javax.swing.JLabel CourseFee_jLabel8;
    private javax.swing.JLabel CourseFee_jLabel9;
    private javax.swing.JButton Delete_jButton;
    private javax.swing.JButton Home_jButton;
    private javax.swing.JLabel StudentInformation_jLabel;
    private javax.swing.JButton Update_jButton;
    private javax.swing.JButton clear_jButton;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JComboBox<String> jComboBox3;
    private javax.swing.JComboBox<String> jComboBox4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSplitPane jSplitPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTextField jTextField9;
    private javax.swing.JLabel mainback_jLabel;
    private javax.swing.JTextField search_jTextField;
    // End of variables declaration//GEN-END:variables
}
