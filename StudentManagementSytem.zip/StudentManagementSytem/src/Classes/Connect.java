
package Classes;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Connect
{
public Statement st;
public ResultSet rs;
public Connection conn;
    public void Connect() 
    {
        conn = null;
        try
        {
            String driverName = "oracle.jdbc.OracleDriver";
            Class.forName(driverName);
            String url = "jdbc:oracle:thin:@localhost:1521:ORCL";
            String user = "admin";
            String pass = "admin";
            conn = DriverManager.getConnection(url,user,pass);
            System.out.println("CONNECTED!!");
        }
        catch(SQLException e)
        {
            System.out.println("FAILED!!"+e.getMessage());
        }
        catch (ClassNotFoundException ex)
        {
            Logger.getLogger(Connect.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    PreparedStatement preparedStatement(String sql) {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

    PreparedStatement prepareStatement(String sql) {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

}
