
package Classes;
import com.sun.glass.events.KeyEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class CourseForm extends javax.swing.JFrame
{
    Connect connect = new Connect();
    
    public CourseForm()
    {
        initComponents();
        connect.Connect();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Add_jButton = new javax.swing.JButton();
        clear_jButton = new javax.swing.JButton();
        Update_jButton = new javax.swing.JButton();
        Delete_jButton = new javax.swing.JButton();
        CourseInformation_jLabel = new javax.swing.JLabel();
        Course_jPanel = new javax.swing.JPanel();
        CourseCode_jLabel = new javax.swing.JLabel();
        coursecode_jTextField = new javax.swing.JTextField();
        coursename_jTextField = new javax.swing.JTextField();
        CourseName_jLabel = new javax.swing.JLabel();
        coursefee_jTextField = new javax.swing.JTextField();
        CourseFee_jLabel1 = new javax.swing.JLabel();
        CreditHours_jTextField = new javax.swing.JTextField();
        CourseDuration_jLabel = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        Home_jButton = new javax.swing.JButton();
        back_jlabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("COURSE IFORMATION FORM");
        setBackground(new java.awt.Color(255, 255, 255));
        setBounds(new java.awt.Rectangle(0, 0, 0, 0));
        setFocusCycleRoot(false);
        setFocusable(false);
        setMinimumSize(new java.awt.Dimension(718, 364));
        setResizable(false);
        setSize(new java.awt.Dimension(718, 364));
        getContentPane().setLayout(null);

        Add_jButton.setBackground(new java.awt.Color(102, 102, 102));
        Add_jButton.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        Add_jButton.setForeground(new java.awt.Color(102, 102, 102));
        Add_jButton.setText("ADD");
        Add_jButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        Add_jButton.setMaximumSize(new java.awt.Dimension(300, 300));
        Add_jButton.setMinimumSize(new java.awt.Dimension(300, 300));
        Add_jButton.setOpaque(false);
        Add_jButton.setPreferredSize(new java.awt.Dimension(300, 300));
        Add_jButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Add_jButtonActionPerformed(evt);
            }
        });
        getContentPane().add(Add_jButton);
        Add_jButton.setBounds(40, 260, 100, 25);

        clear_jButton.setBackground(new java.awt.Color(102, 102, 102));
        clear_jButton.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        clear_jButton.setForeground(new java.awt.Color(102, 102, 102));
        clear_jButton.setText("CLEAR");
        clear_jButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        clear_jButton.setMaximumSize(new java.awt.Dimension(100, 25));
        clear_jButton.setMinimumSize(new java.awt.Dimension(100, 25));
        clear_jButton.setOpaque(false);
        clear_jButton.setPreferredSize(new java.awt.Dimension(100, 25));
        clear_jButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clear_jButtonActionPerformed(evt);
            }
        });
        getContentPane().add(clear_jButton);
        clear_jButton.setBounds(270, 290, 100, 25);

        Update_jButton.setBackground(new java.awt.Color(102, 102, 102));
        Update_jButton.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        Update_jButton.setForeground(new java.awt.Color(102, 102, 102));
        Update_jButton.setText("UPDATE");
        Update_jButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        Update_jButton.setMaximumSize(new java.awt.Dimension(300, 300));
        Update_jButton.setMinimumSize(new java.awt.Dimension(300, 300));
        Update_jButton.setOpaque(false);
        Update_jButton.setPreferredSize(new java.awt.Dimension(300, 300));
        Update_jButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Update_jButtonActionPerformed(evt);
            }
        });
        getContentPane().add(Update_jButton);
        Update_jButton.setBounds(160, 260, 100, 25);

        Delete_jButton.setBackground(new java.awt.Color(102, 102, 102));
        Delete_jButton.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        Delete_jButton.setForeground(new java.awt.Color(102, 102, 102));
        Delete_jButton.setText("DELETE");
        Delete_jButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        Delete_jButton.setMaximumSize(new java.awt.Dimension(100, 25));
        Delete_jButton.setMinimumSize(new java.awt.Dimension(100, 25));
        Delete_jButton.setOpaque(false);
        Delete_jButton.setPreferredSize(new java.awt.Dimension(100, 25));
        Delete_jButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Delete_jButtonActionPerformed(evt);
            }
        });
        getContentPane().add(Delete_jButton);
        Delete_jButton.setBounds(160, 290, 100, 25);

        CourseInformation_jLabel.setFont(new java.awt.Font("Buxton Sketch", 0, 36)); // NOI18N
        CourseInformation_jLabel.setForeground(new java.awt.Color(255, 255, 255));
        CourseInformation_jLabel.setText("COURSE INFORMATION");
        getContentPane().add(CourseInformation_jLabel);
        CourseInformation_jLabel.setBounds(67, 30, 297, 27);

        Course_jPanel.setBackground(new java.awt.Color(204, 204, 204));
        Course_jPanel.setForeground(new java.awt.Color(102, 102, 0));
        Course_jPanel.setOpaque(false);
        Course_jPanel.setLayout(null);

        CourseCode_jLabel.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        CourseCode_jLabel.setForeground(new java.awt.Color(255, 255, 255));
        CourseCode_jLabel.setText("COURSE CODE");
        CourseCode_jLabel.setPreferredSize(new java.awt.Dimension(145, 20));
        Course_jPanel.add(CourseCode_jLabel);
        CourseCode_jLabel.setBounds(21, 23, 145, 20);

        coursecode_jTextField.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        coursecode_jTextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                coursecode_jTextFieldKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                coursecode_jTextFieldKeyReleased(evt);
            }
        });
        Course_jPanel.add(coursecode_jTextField);
        coursecode_jTextField.setBounds(186, 21, 150, 25);

        coursename_jTextField.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        Course_jPanel.add(coursename_jTextField);
        coursename_jTextField.setBounds(186, 66, 150, 25);

        CourseName_jLabel.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        CourseName_jLabel.setForeground(new java.awt.Color(255, 255, 255));
        CourseName_jLabel.setText("COURSE NAME");
        CourseName_jLabel.setPreferredSize(new java.awt.Dimension(145, 20));
        Course_jPanel.add(CourseName_jLabel);
        CourseName_jLabel.setBounds(21, 68, 145, 20);

        coursefee_jTextField.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        Course_jPanel.add(coursefee_jTextField);
        coursefee_jTextField.setBounds(186, 111, 150, 25);

        CourseFee_jLabel1.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        CourseFee_jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        CourseFee_jLabel1.setText("COURSE FEE");
        CourseFee_jLabel1.setPreferredSize(new java.awt.Dimension(145, 20));
        Course_jPanel.add(CourseFee_jLabel1);
        CourseFee_jLabel1.setBounds(21, 113, 145, 20);

        CreditHours_jTextField.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        CreditHours_jTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CreditHours_jTextFieldActionPerformed(evt);
            }
        });
        Course_jPanel.add(CreditHours_jTextField);
        CreditHours_jTextField.setBounds(186, 156, 150, 25);

        CourseDuration_jLabel.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        CourseDuration_jLabel.setForeground(new java.awt.Color(255, 255, 255));
        CourseDuration_jLabel.setText("CREDIT HOURS");
        CourseDuration_jLabel.setPreferredSize(new java.awt.Dimension(145, 20));
        Course_jPanel.add(CourseDuration_jLabel);
        CourseDuration_jLabel.setBounds(21, 158, 145, 20);

        getContentPane().add(Course_jPanel);
        Course_jPanel.setBounds(20, 70, 350, 200);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Course Code", "Course Name"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(400, 0, 320, 370);

        Home_jButton.setBackground(new java.awt.Color(102, 102, 102));
        Home_jButton.setFont(new java.awt.Font("Buxton Sketch", 1, 18)); // NOI18N
        Home_jButton.setForeground(new java.awt.Color(102, 102, 102));
        Home_jButton.setText("HOME");
        Home_jButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        Home_jButton.setMaximumSize(new java.awt.Dimension(100, 25));
        Home_jButton.setMinimumSize(new java.awt.Dimension(100, 25));
        Home_jButton.setOpaque(false);
        Home_jButton.setPreferredSize(new java.awt.Dimension(100, 25));
        Home_jButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Home_jButtonActionPerformed(evt);
            }
        });
        getContentPane().add(Home_jButton);
        Home_jButton.setBounds(40, 290, 100, 25);

        back_jlabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/fiction.jpg"))); // NOI18N
        getContentPane().add(back_jlabel);
        back_jlabel.setBounds(0, 0, 720, 370);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void Add_jButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Add_jButtonActionPerformed
        
    }//GEN-LAST:event_Add_jButtonActionPerformed

    private void Home_jButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Home_jButtonActionPerformed
        HOME h = new HOME();
        h.setVisible(true);
        dispose();
    }//GEN-LAST:event_Home_jButtonActionPerformed

    private void Delete_jButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Delete_jButtonActionPerformed
        
    }//GEN-LAST:event_Delete_jButtonActionPerformed

    private void Update_jButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Update_jButtonActionPerformed
            
      
      
    }//GEN-LAST:event_Update_jButtonActionPerformed

    private void clear_jButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clear_jButtonActionPerformed

       
       
    }//GEN-LAST:event_clear_jButtonActionPerformed

    private void coursecode_jTextFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_coursecode_jTextFieldKeyReleased

        
    }//GEN-LAST:event_coursecode_jTextFieldKeyReleased

    private void coursecode_jTextFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_coursecode_jTextFieldKeyPressed
        
    }//GEN-LAST:event_coursecode_jTextFieldKeyPressed

    private void CreditHours_jTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CreditHours_jTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CreditHours_jTextFieldActionPerformed

    public static void main(String args[]) 
    {
        java.awt.EventQueue.invokeLater(new Runnable() 
        {
            public void run()
            {
                new CourseForm().setVisible(true);
            }
        });
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Add_jButton;
    private javax.swing.JLabel CourseCode_jLabel;
    private javax.swing.JLabel CourseDuration_jLabel;
    private javax.swing.JLabel CourseFee_jLabel1;
    private javax.swing.JLabel CourseInformation_jLabel;
    private javax.swing.JLabel CourseName_jLabel;
    private javax.swing.JPanel Course_jPanel;
    private javax.swing.JTextField CreditHours_jTextField;
    private javax.swing.JButton Delete_jButton;
    private javax.swing.JButton Home_jButton;
    private javax.swing.JButton Update_jButton;
    private javax.swing.JLabel back_jlabel;
    private javax.swing.JButton clear_jButton;
    private javax.swing.JTextField coursecode_jTextField;
    private javax.swing.JTextField coursefee_jTextField;
    private javax.swing.JTextField coursename_jTextField;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
